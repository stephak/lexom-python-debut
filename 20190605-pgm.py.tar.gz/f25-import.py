import formatage

d=formatage.adresse.Adresse("8 square Louis Massignon",cp="35000",ville="Rennes")
d.print()